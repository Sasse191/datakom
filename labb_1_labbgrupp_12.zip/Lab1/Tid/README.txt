Sanchir Tumentsetseg | Emma Väisänen

How to run:
1. Compile the files with "make"
2. Run on terminal 1: "sudo ./server"
3. Run on terminal 2: "sudo ./klient"

