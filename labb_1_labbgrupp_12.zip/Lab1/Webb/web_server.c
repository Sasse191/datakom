#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <arpa/inet.h>

#define PORTNR 9000
#define MAXBUF 1024
#define METHODLEN 10
#define PATHLEN 256
#define FILEPATHLEN 512
#define WEBSITE "./sample_website"

void handle_file(int client_sd, const char *filepath);
const char *get_mime(const char *path);

void server()
{
    int request_sd, client_sd;
    char buf[MAXBUF];
    struct sockaddr_in serveraddr, clientaddr;
    socklen_t clientaddrlen;

    request_sd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (request_sd < 0)
    {
        perror("Socket creation failed");
        return;
    }

    int opt = 1;
    setsockopt(request_sd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

// address structure for server
    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = INADDR_ANY;
    serveraddr.sin_port = htons(PORTNR);

    if (bind(request_sd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0)
    {
        perror("Bind failed");
        return;
    }

    if (listen(request_sd, SOMAXCONN) < 0)
    {
        perror("Listen failed");
        return;
    }
    
    printf("Server is running on port %d...\n", PORTNR);

    while (1)
    {
        clientaddrlen = sizeof(clientaddr);
        client_sd = accept(request_sd, (struct sockaddr *)&clientaddr, &clientaddrlen);
        if (client_sd < 0)
            continue;

        read(client_sd, buf, sizeof(buf) - 1);
        buf[sizeof(buf) - 1] = '\0';

        char method[METHODLEN], path[PATHLEN];
        sscanf(buf, "%s %s", method, path);

        printf("Received request: %s %s\n", method, path);

        char filepath[FILEPATHLEN];
        snprintf(filepath, sizeof(filepath), "%s%s", WEBSITE, strcmp(path, "/") == 0 ? "/index.html" : path);

        handle_file(client_sd, filepath);
        close(client_sd);
    }
    close(request_sd);
}

void handle_file(int client_sd, const char *filepath)
{
    char response[MAXBUF];
    int file_fd = open(filepath, O_RDONLY);

    if (file_fd < 0)
    {
        const char *not_found = "HTTP/1.1 404 Not Found\r\n"
                                "Content-Length: 13\r\n"
                                "Content-Type: text/html\r\n"
                                "Connection: close\r\n\r\n"
                                "404 Not Found";
        write(client_sd, not_found, strlen(not_found));

        printf("404 Not Found: %s\n", filepath);
    }
    else
    {
        struct stat file_stat;
        fstat(file_fd, &file_stat);
        off_t filesize = file_stat.st_size;
        const char *mime_type = get_mime(filepath);

        printf("Serving file: %s\n", filepath);
        printf("Content-Type: %s\n", mime_type);
        printf("Content-Length: %ld bytes\n", filesize);

        snprintf(response, sizeof(response),
                 "HTTP/1.1 200 OK\r\n"
                 "Server: Demo Web Server\r\n"
                 "Content-Length: %ld\r\n"
                 "Content-Type: %s\r\n"
                 "Connection: close\r\n\r\n",
                 filesize, mime_type);
        write(client_sd, response, strlen(response));

        ssize_t bytes;
        while ((bytes = read(file_fd, response, sizeof(response))) > 0)
        {
            write(client_sd, response, bytes);
        }
        close(file_fd);
    }
}

const char *get_mime(const char *path)
{
    const char *ext = strrchr(path, '.');
    if (!ext)
        return "application/octet-stream";
    if (strcmp(ext, ".html") == 0)
        return "text/html";
    if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0)
        return "image/jpeg";
    if (strcmp(ext, ".png") == 0)
        return "image/png";
    return "application/octet-stream";
}

int main()
{
    server();
    return 0;
}