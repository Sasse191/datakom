#include "Sim_Engine.h"

enum sendState
{
  WAIT_ACK,
  WAIT_L5
};

struct sender
{
  enum sendState state;
  int seq;
  struct pkt last;
  float est_rtt;
} A;

int get_checksum(struct pkt *packet)
{
  int checksum = 0;
  checksum += packet->seqnum;
  checksum += packet->acknum;
  for (int i = 0; i < 20; ++i)
    checksum += packet->payload[i];
  return checksum;
}

/* Called from layer 5, passed the data to be sent to other side */
void A_output(struct msg message)
{
  if (A.state != WAIT_L5)
  {
    return;
  }

  struct pkt packet;
  packet.seqnum = A.seq;
  packet.acknum = 0;
  memmove(packet.payload, message.data, 20);
  packet.checksum = get_checksum(&packet);

  A.last = packet;
  A.state = WAIT_ACK;

  tolayer3(0, packet);
  starttimer(0, A.est_rtt);
}

/* Called from layer 3, when a packet arrives for layer 4 */
void A_input(struct pkt packet)
{
  /* TODO */
  if (A.state != WAIT_ACK)
  {
    return;
  }

  if (packet.checksum != get_checksum(&packet))
  {
    return;
  }

  if (packet.acknum != A.seq)
  {
    return;
  }

  stoptimer(0);
  A.seq = 1 - A.seq;
  A.state = WAIT_L5;
}

/* Called when A's timer goes off */ // This routine will be called when A's timer expires
void A_timerinterrupt()
{
  if (A.state != WAIT_ACK)
  {
    return;
  }
  tolayer3(0, A.last);
  starttimer(0, A.est_rtt);
}

/* The following routine will be called once (only) before any other */
/* Host A routines are called. You can use it to do any initialization */
void A_init()
{
  A.seq = 0;
  A.state = WAIT_L5;
  A.est_rtt = 10;
}
