#include "Sim_Engine.h"

struct Receiver
{
  int seq;
} B;

int get_checksum(struct pkt *packet);

void send_ack(int AorB, int ack)
{
  struct pkt packet;
  packet.acknum = ack;
  packet.checksum = get_checksum(&packet);
  tolayer3(1, packet);
}

/* Called from layer 5, passed the data to be sent to other side */
void B_output(struct msg message)
{
  /* DON'T IMPLEMENT */
}

/* Called from layer 3, when a packet arrives for layer 4 */
void B_input(struct pkt packet)
{
  /* TODO */
  if (packet.checksum != get_checksum(&packet))
  {
    send_ack(1, 1 - B.seq);
    return;
  }

  if (packet.seqnum != B.seq)
  {
    send_ack(1, 1 - B.seq);
    return;
  }

  tolayer5(1, packet.payload);

  send_ack(1, B.seq);
  B.seq = 1 - B.seq;
}

/* Called when B's timer goes off */
void B_timerinterrupt()
{
  /* TODO */
  send_ack(1, B.seq);
}

/* The following routine will be called once (only) before any other */
/* Host B routines are called. You can use it to do any initialization */
void B_init()
{
  /* TODO */
  B.seq = 0;
}
