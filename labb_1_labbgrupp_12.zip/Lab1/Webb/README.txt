Sanchir Tumentsetseg | Emma Väisänen
How to run
1. Enter "make" to compile file
2. Enter "./web_server" to run file
3. "ctrl + c" to kill program

NOTE!
Don't forget to kill the port to use it again!

TODO:
"sudo netstat -tulpn | grep : <PORT> " ~ for finding the ID
"sudo kill <ID> " 

DONE!
