#include "adjlist.h"
// local prototypes
pnode create_node(char nname);
pnode node_cons(pnode first, pnode second);
pedge create_edge(char to, double weight);
pedge edge_cons(pedge first, pedge second);
pedge _add_edge(pedge edge, char to, double weight);
pedge _rem_edge(pedge edges, char to);
void remove_all_edges_to(pnode G, char name);
void remove_all_edges_from(pnode G, char name);

// create_node: creates node with name nname
pnode create_node(char nname) {
    pnode new_node = (pnode)calloc(1, sizeof(node));
    new_node->name = nname;
    new_node->d = INFINITY;
    new_node->pi = '-';
    new_node->next_node = NULL;
    new_node->edges = NULL;
    return new_node;
}
// function implementations
bool is_empty(pnode G) { return !G; }
char get_name(pnode G) { return is_empty(G) ? '-' : G->name; }
pnode set_name(pnode G, char name) {
    if (!is_empty(G)) G->name = name;
    return G;
}
pedge get_edges(pnode G) { return is_empty(G) ? NULL : G->edges; }
pnode set_edges(pnode G, pedge E) {
    if (!is_empty(G)) G->edges = E;
    return G;
}
pnode get_next(pnode G) { return is_empty(G) ? NULL : G->next_node; }
// see node_cons() for the corresponding "set-next" function
double get_d(pnode G) { return is_empty(G) ? INFINITY : G->d; }
pnode set_d(pnode G, double d) {
    if (!is_empty(G)) G->d = d;
    return G;
}
char get_pi(pnode G) { return is_empty(G) ? '-' : G->pi; }
pnode set_pi(pnode G, char pi) {
    if (!is_empty(G)) G->pi = pi;
    return G;
}
// node_cons: connects two nodes in adjacency list
pnode node_cons(pnode first, pnode second) {
    if (is_empty(first)) return NULL;
    first->next_node = second;
    return first;
}
// add_node: adds a new node with name nname to adjacency list G in lexicographical order. If it already exists in graph, nothing is done
pnode add_node(pnode G, char nname) {
    if (is_empty(G)) return create_node(nname);
    if (get_name(G) == nname) return G;
    if (get_name(G) > nname) {
        pnode P = create_node(nname);
        return node_cons(P, G);
    }
    G->next_node = add_node(get_next(G), nname);
    return G;
}
// rem_node: removes node with name name from adjacency list G
//           if node does not exist, nothing happens
pnode rem_node(pnode G, char name) {
    if (is_empty(G))
        return G;
    if (get_name(G) > name)
        return G;
    if (get_name(G) == name) {          // make sure first node is safe
        remove_all_edges_to(G, name);
        remove_all_edges_from(G, name);
        pnode temp = get_next(G);
        free(G);
        return temp;
    }
    
    pnode walknode = G;

    while (name > get_name(get_next(walknode)) && !is_empty(walknode))  //walknode one before the node we want to remove && walknode is not empty (signaling end of list)
        walknode = get_next(walknode);

    if (get_name(get_next(walknode)) == name) {
        remove_all_edges_to(G, name);
        remove_all_edges_from(G, name);
        pnode temp = get_next(walknode);
        free(get_next(walknode));
        node_cons(walknode, get_next(temp));
    }

    return G;
}
// get_node: returns pointer to node with name name from adjacency list G
pnode get_node(pnode G, char name) {
    pnode T = G;
    while (!is_empty(T)) {
        if (get_name(T) == name)
            return T;
        T = get_next(T);
    }
    return NULL;
}
// get_node: returns true if node with name name exists in adjacency list G
//           false otherwise
bool find_node(pnode G, char name) {
    return is_empty(G) ? false
        : get_name(G) == name ? true
        : find_node(G->next_node, name);
}
// create_edge: creates edge
pedge create_edge(char to, double weight) {
    pedge new_edge = (pedge)calloc(1, sizeof(edge));
    new_edge->to = to;
    new_edge->weight = weight;
    return new_edge;
}
bool edge_empty(pedge E) { return !E; }
char get_to(pedge E) { return edge_empty(E) ? '-' : E->to; }
pedge set_to(pedge E, char to) {
    if (!edge_empty(E)) E->to = to;
    return E;
}
double get_weight(pedge E) { return edge_empty(E) ? INFINITY : E->weight; }
pedge set_weight(pedge E, double weight) {
    if (!edge_empty(E)) E->weight = weight;
    return E;
}
pedge get_next_edge(pedge E) { return edge_empty(E) ? NULL : E->next_edge; }
// edge_cons: connects two edges in edge list
pedge edge_cons(pedge first, pedge second) {
    if (edge_empty(first)) return NULL;
    first->next_edge = second;
    return first;
}
// upd_edge: updates edge E to new weight
pedge upd_edge(pedge E, double weight) {
    if (edge_empty(E)) return NULL;
    E->weight = weight;
    return E;
}
// _add_edge: creates and connects new edge to edge-list
pedge _add_edge(pedge E, char to, double weight) {
    if (edge_empty(E)) return create_edge(to, weight);
    if (get_to(E) == to) return E;
    if (get_to(E) > to) {
        pedge T = create_edge(to, weight);
        return edge_cons(T, E);
    }
    E->next_edge = _add_edge(get_next_edge(E), to, weight);
    return E;
}
// add_edge: adds an edge to G by finding correct start node and then calling _add_edge to create new edge
void add_edge(pnode G, char from, char to, double weight) {
    if (is_empty(G)) return;
    pnode T = get_node(G, from);
    if (is_empty(T)) return;
    pedge P = get_edges(T);
    T->edges = _add_edge(P, to, weight);
}
// _find_edge: finds edge in edge-list
bool _find_edge(pedge E, char to) {
    if (get_to(E) == to)
        return true;
    else if (edge_empty(E))
        return false;
    else
        return _find_edge(get_next_edge(E), to);
}
// find_edge: returns true if edge between from and to exists, false otherwise
bool find_edge(pnode G, char from, char to) {
    if (_find_edge(get_edges(get_node(G, from)), to)) return true;

    return false;
}
// _edge_cardinality: returns the number of edges from one node
int _edge_cardinality(pedge E) {
    if (edge_empty(E))
        return 0;
    return 1 + _edge_cardinality(get_next_edge(E));
}
// edge_cardinality: returns the total number of edges in G
int edge_cardinality(pnode G) {
    int count = 0;
    while (!is_empty(G))
    {
        count += _edge_cardinality(get_edges(G));
        G = get_next(G);
    }
    return count;
}
// _self_loops: returns the number of edges going back to
//              source node
int _self_loops(pedge E, char src) {

    //TODO, Vi har gjort den iterativt, så vi aldrig behövde använda oss av _self_loops hjälp funktionen!
    //Kolla rad 201-205
    return 0;
}
// self_loops: counts the number of self-loops, i.e. edges to and from
//             the same node
int self_loops(pnode G) {
    int count = 0;
    for (size_t i = 0; i < node_cardinality(G); i++)
        count += find_edge(G, pos_to_name(G, i), pos_to_name(G, i)) ?  1 : 0;
    return count;
}
// _rem_edge: removes edge from edge-list
pedge _rem_edge(pedge E, char to) {
    if (edge_empty(E)) return NULL;
    if (get_to(E) == to) {
        pedge T = get_next_edge(E);
        free(E);
        return T;
    }
    if (get_to(E) < to)
        E->next_edge = _rem_edge(get_next_edge(E), to);
    return E;
}
// rem_edge: removes edge from G
void rem_edge(pnode G, char from, char to) {

    pnode T = get_node(G, from);
    if (is_empty(T)) return;

    T->edges = _rem_edge(get_edges(T), to);
}
// remove_all_edges_to: removes all edges going towards node with name name
void remove_all_edges_to(pnode G, char name) {
    pnode T = G;
    while (!is_empty(T))
    {
        rem_edge(G, get_name(T), name);
        T = get_next(T);
    }
}
// remove_all_edges_from: removes all edges from node with name name
void remove_all_edges_from(pnode G, char name) {
    pnode T = G;
    while (!edge_empty(get_edges(T)))
    {
        pedge P = T->edges;
        T->edges = get_next_edge(get_edges(T));
        free(P);
    }
}
// node_cardinality: returns the number of nodes in G
int node_cardinality(pnode G) {
    if (is_empty(G)) return 0;
    int i = 1;
    pnode T = G;
    while (!is_empty(get_next(T))) {
        T = get_next(T);
        i++;
    }
    return i;
}
// name_to_pos: returns position of node with name c, -1 if not found
int name_to_pos(pnode G, char c) {
    if (is_empty(G)) return -1;
    if (get_name(G) > c) return -1;
    pnode T = G;
    int i = 0;
    while (!is_empty(get_next(T))) {
        if (get_name(T) == c) return i;
        T = get_next(T);
        i++;
    }
    return i;
}
// pos_to_name: returns name of node at position pos in G
char pos_to_name(pnode G, int pos) {
    if (is_empty(G)) return '-';
    if (pos < 0) return '-';
    pnode T = G;
    for (int i = 0; i < pos; i++)
    {
        T = get_next(T);
    }
    return get_name(T);
}
// list_to_pos: creates adjacency matrix from adjacency list
void list_to_matrix(pnode G, double matrix[MAXNODES][MAXNODES]) {
    pnode Y = G;
    int size = node_cardinality(G);
    for (size_t i = 0; i < size; i++)
    {
        pedge X = get_edges(Y);
        for (size_t j = 0; j < size; j++)
        {
            if (get_to(X) == pos_to_name(G, j))
            {
                matrix[i][j] = get_weight(X);
                X = get_next_edge(X);
            }
            else {
                matrix[i][j] = INFINITY;
            }
        }
        Y = get_next(Y);
    }
}

//Alexander Vagi, Sanchir Tumentsetseg